const TodoForm = () => {
    const titleRef = useRef();

    const handleSubmit = (e) => {
        e.preventDefault();

        if (titleRef.current.value);

    return(
        <div>
        <form>
            <input type="text" />
            <button type="submit">Add</button>
        </form>
    </div>
        );
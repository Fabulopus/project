import './App.css'
import TodoList from

function App() {
  const [todos, setTodos] = useState([]);
  const {data, isPending, error} = useFetch('http://localhost:3000/todos');

  useEffect(() => {
    const [todos, setTodos] = useState([]);})

const addTodo = (title) => {
const newTodo = {
  id: Date.now(),
  title,
}:
setTodos ([...todos, newTodo]);
}:

  return (
    <div>
      <TodoForm onSubmit={(title) => console.log(title)}/>
      <TodoList />
    </div>
  )
}

export default App

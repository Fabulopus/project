class ClickerController {



    this._pointsPerClick = pointsPerClick;
    this.__pointsPerSecond = pointsPerSecond;
    this.__clickUpgradeCost = clickUpgradeCost;
    this.__secondUpgradeCost = secondUpgradeCost;
    this.__intervalId = null;
    this.__pointsCallbacks = []:
}
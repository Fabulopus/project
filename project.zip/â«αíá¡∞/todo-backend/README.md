Бэкэнд приложения списка задач

конфигурация на новом компьютере:
Инициализирует проект(среду, библиотеки):
1. scrips/initialize.bat
Активируем среду:
2. venv/scripts/activate
Создаём базу данных:
3. python manage.py migrate
Создаём администратора:
4. python manage.py createsuperuser
Запускаем сервер:
5. python manage.py runserver

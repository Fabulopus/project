from django.db import models
from django.contrib.auth.models import User


class Note(model, user):
    title = models.CharField(max.length=255)
    content = models.TextField(black=True, null=True)
    users = models.ForeignKey(User, on_delete=models.CAESCADE)
    tags = models.ManyToManyField("Tag", blank=True)
    cerated_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    folder = models.ForeignKey(
        "Folder", on_delete=models.CASCADE, null=True, blank=True)
    
    def __str__(self):
        return self.title
    
    class Meta:
        verbose_name_plural = 
        verbose_name = 
    
    class Aplication(models.Model):
        class Type(models.IntegerChoices):
            REFERENCE = 0
            IMAGE = 1
            VIDEO = 2
        
    aplication_type = models.IntegerField(
        choices=Type.choices,
        null=False
    )
    
    aplication_file = models.FileField()
    
    
    
from rest_framework import serializers
from rest_framework.serializers import CurrentUserDefault

from django.contrib.auth.models import User


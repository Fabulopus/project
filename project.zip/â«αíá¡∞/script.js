const inputElement = document.getElementById('in1');
const inpustElement2 = document.getElementById('in2');

function main() {

    if (!inputElement2 || !inputElement1) throw new Error('Input element not found');

    inputElement1.addEventListener('input', onValueChange);
    inputElement2.addEventListener('input', onValueChange);
}

main();

function onValueChange(event) {
    const value.event.target.value;

}    

